import LinearCardTag from "./LinearCardTag";

export { LinearCardTag };
