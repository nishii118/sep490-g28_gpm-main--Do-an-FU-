import React from "react";

const ProjectSkeleton = () => {
  return <div>ProjectSkeleton</div>;
};

export default ProjectSkeleton;
