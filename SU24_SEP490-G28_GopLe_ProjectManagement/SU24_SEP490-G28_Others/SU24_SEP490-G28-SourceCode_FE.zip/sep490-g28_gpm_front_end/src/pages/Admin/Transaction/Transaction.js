const Transaction = () => {
    return (
        <>
            Transaction
        </>
    )
}

export default Transaction