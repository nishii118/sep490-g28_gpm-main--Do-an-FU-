import HomePage from "./Home";
import ProjectDetail from "./ProjectDetail";
import Projects from "./Projects";
import UserAnalysis from "./UserProfile";
import NewsList from "./NewsList";

export { HomePage, Projects, ProjectDetail, UserAnalysis, NewsList };
