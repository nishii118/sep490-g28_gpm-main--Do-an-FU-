import DefaultLayout from "./DefaultLayout.jsx";
import AdminLayout from "./AdminLayout.jsx";

export { DefaultLayout, AdminLayout };
