export const images = {
    logo: require("./images/logo.jpg")
};
