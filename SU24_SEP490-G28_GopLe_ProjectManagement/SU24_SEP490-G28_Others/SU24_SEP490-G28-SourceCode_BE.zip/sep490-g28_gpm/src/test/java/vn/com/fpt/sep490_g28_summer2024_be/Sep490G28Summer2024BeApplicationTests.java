package vn.com.fpt.sep490_g28_summer2024_be;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sep490G28Summer2024BeApplicationTests {

    @Test
    void contextLoads() {
    }

}
