package vn.com.fpt.sep490_g28_summer2024_be.service.wrongdonation;


import java.math.BigInteger;
import java.util.concurrent.CompletableFuture;

public interface WrongDonationService {

    CompletableFuture<Void> updateWrongDonation(BigInteger id);

}
