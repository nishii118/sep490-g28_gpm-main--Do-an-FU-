package vn.com.fpt.sep490_g28_summer2024_be.common;

public enum DonationStatus {
    IN,
    OUT
}
