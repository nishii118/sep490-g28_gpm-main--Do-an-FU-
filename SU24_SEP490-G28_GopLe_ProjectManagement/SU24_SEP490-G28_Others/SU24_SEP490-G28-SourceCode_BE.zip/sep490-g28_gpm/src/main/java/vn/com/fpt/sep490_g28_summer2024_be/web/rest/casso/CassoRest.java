package vn.com.fpt.sep490_g28_summer2024_be.web.rest.casso;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import vn.com.fpt.sep490_g28_summer2024_be.dto.ApiResponse;
import vn.com.fpt.sep490_g28_summer2024_be.dto.casso.WebhookResponseDTO;
import vn.com.fpt.sep490_g28_summer2024_be.service.casso.CassoService;


@RestController
@RequestMapping("/api/casso")
@RequiredArgsConstructor
public class CassoRest {

    private final CassoService cassoService;

    @PostMapping("/in")
    public ApiResponse<?> addInPayment(@RequestBody WebhookResponseDTO payload){
        System.out.println(payload);
        return ApiResponse.builder()
                .data(cassoService.handleInPayment(payload.getData().get(0)))
                .build();
    }

    @PostMapping("/out")
    public ApiResponse<?> addOutPayment(@RequestBody WebhookResponseDTO payload){
        System.out.println(payload);
        return ApiResponse.builder()
                .data(cassoService.handleOutPayment(payload.getData().get(0)))
                .build();
    }
}
