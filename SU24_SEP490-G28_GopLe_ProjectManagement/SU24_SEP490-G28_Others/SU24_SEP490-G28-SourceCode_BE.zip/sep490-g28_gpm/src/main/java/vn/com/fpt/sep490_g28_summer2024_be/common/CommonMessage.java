package vn.com.fpt.sep490_g28_summer2024_be.common;

public class CommonMessage {
    public static String ADD_SUCCESSFULLY = "Tạo mới thành công!";
    public static String UPDATE_SUCCESSFULLY = "SUCCESSFULLY!";
    public static String GET_SUCCESFULLY = "Lấy danh sách thành công";
}
