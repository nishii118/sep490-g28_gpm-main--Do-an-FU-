package vn.com.fpt.sep490_g28_summer2024_be.service.wrongdonation;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import vn.com.fpt.sep490_g28_summer2024_be.common.ErrorCode;
import vn.com.fpt.sep490_g28_summer2024_be.dto.project.interfacedto.ProjectTransactionDTO;
import vn.com.fpt.sep490_g28_summer2024_be.entity.Donation;
import vn.com.fpt.sep490_g28_summer2024_be.entity.Project;
import vn.com.fpt.sep490_g28_summer2024_be.entity.WrongDonation;
import vn.com.fpt.sep490_g28_summer2024_be.exception.AppException;
import vn.com.fpt.sep490_g28_summer2024_be.repository.DonationRepository;
import vn.com.fpt.sep490_g28_summer2024_be.repository.ProjectRepository;
import vn.com.fpt.sep490_g28_summer2024_be.repository.WrongDonationRepository;

import java.math.BigInteger;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

@Service
@Slf4j
public class DefaultWrongDonationService implements WrongDonationService{

    private final WrongDonationRepository wrongDonationRepository;
    private final ProjectRepository projectRepository;
    private final DonationRepository donationRepository;
    private final Executor executor;

    public DefaultWrongDonationService(WrongDonationRepository wrongDonationRepository, ProjectRepository projectRepository,
                                       DonationRepository donationRepository,
                                       @Qualifier("scheduleExecutor") Executor executor) {
        this.wrongDonationRepository = wrongDonationRepository;
        this.projectRepository = projectRepository;
        this.donationRepository = donationRepository;
        this.executor = executor;
    }

    @Override
    @Async("scheduleExecutor")
    @Transactional
    public CompletableFuture<Void> updateWrongDonation(BigInteger id) {
        WrongDonation wrongDonation = wrongDonationRepository.findById(id).orElseThrow(() -> new AppException(ErrorCode.HTTP_BAD_REQUEST));
        return CompletableFuture.runAsync(() -> {
            if (wrongDonation.getDonation().getProject() != null){
                Project project = wrongDonation.getDonation().getProject();
                Donation donation = wrongDonation.getDonation();

                ProjectTransactionDTO validProject = projectRepository.findProjectByCampaignIdAndDonationDescriptionAndStatus(null,
                        project.getCampaign().getCampaignId(), 2, false);

                validProject = validProject != null ? validProject : projectRepository.findProjectByCampaignIdAndDonationDescriptionAndStatus(null,
                        null, 2, false);

                log.info("chạy phần có dự án");

                if (validProject != null){
                    donation.setTransferredProject(Project.builder()
                                    .projectId(validProject.getProjectId())
                                    .code(validProject.getCode())
                            .build());
                    donation.setNote("Dự án bạn đang quyên góp hiện đã đủ quyên góp, nên chuyển sang dự án "+validProject.getCode());
                    donationRepository.save(donation);
                    wrongDonationRepository.delete(wrongDonation);
                }
            }else {
                Donation donation = wrongDonation.getDonation();

                ProjectTransactionDTO validProject = projectRepository.findProjectByCampaignIdAndDonationDescriptionAndStatus(null,
                        null, 2, false);

                log.info("chạy phần không có dự án");

                if (validProject != null){
                    donation.setTransferredProject(Project.builder()
                            .projectId(validProject.getProjectId())
                            .code(validProject.getCode())
                            .build());
                    donation.setNote("Dự án bạn đang quyên góp hiện đã đủ quyên góp, nên chuyển sang dự án "+validProject.getCode());
                    donationRepository.save(donation);
                    wrongDonationRepository.delete(wrongDonation);
                }
            }
        }, executor);
    }
}
